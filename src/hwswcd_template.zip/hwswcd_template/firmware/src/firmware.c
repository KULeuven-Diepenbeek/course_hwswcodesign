#include "print.h"

void main(void) {
	
	print_chr('h');
	print_str("ello world");
	    
	while(1);
}
