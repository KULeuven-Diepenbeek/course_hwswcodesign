#include "print.h"

int main(void) {

	print_str("hello world\n");

}
