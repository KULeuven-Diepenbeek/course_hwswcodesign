# Example folder structure for HW/SW codesign

